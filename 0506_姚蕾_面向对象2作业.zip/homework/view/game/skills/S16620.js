export default class S16620{
    constructor(){
        this.name = "回旋打击";
        this.ico = 'sources/skills/16620.png'
    }
}
// 类 对象的抽象； 基类：类的抽象；
import MyEvent from '../MyEvent.js';
export default class Hero extends MyEvent{
    constructor(name,ico,skills){
        super();
        this.name = name;
        this.ico = ico;
        this.skills = skills;
        this.addEvent("myevent",this.init);
        this.addEvent("myevent",this.showico);
    }
    init(){
        console.log("初始化..."+name);
    }
    showico(){
        console.log("展示图标");
    }
   
    fire(key){
        console.log("释放了："+this.skills[key].name)
    }
}
export default class Y1{
    constructor(){
        this.name = "亚瑟皮肤一";
        this.ico = 'sources/heros/yase1.png';
        this.img = 'sources/skins/301660.png'
    }
}
export default class Y3{
    constructor(){
        this.name = "亚瑟皮肤三";
        this.ico = 'sources/heros/yase3.png';
        this.img = 'sources/skins/301662.png'
    }
}
export default class Y2{
    constructor(){
        this.name = "亚瑟皮肤二";
        this.ico = 'sources/heros/yase2.png';
        this.img = 'sources/skins/301661.png'
    }
}
export default class MyEvent {
    constructor() {
        this.handles = {};
    }
    addEvent(eventName, fn) {
        if (typeof this.handles[eventName] === 'undefined') {
            this.handles[eventName] = [];
        }
        //收集事件
        this.handles[eventName].push(fn);
    }
    trigger(eventName) {
        this.handles[eventName].forEach(fn => {
            fn();
        })
    }
    // 移除自定义事件；（作业）
    removeEvent(eventName,fn) {
        if(fn != undefined){
            let index =this.handles[eventName].getArrayIndex(fn);
            delete  this.handles[eventName][index];
        }else{
            this.handles[eventName] = [];
        }
        
        

    }



}

//采用prototype原型实现方式，查找元素在数组中的索引值
Array.prototype.getArrayIndex=function(obj){
    for(var i=0;i<this.length;i++){
     if(this[i]===obj){
      return i;
        }
    }
       return -1;
   }
   
  
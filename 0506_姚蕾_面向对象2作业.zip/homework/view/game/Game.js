// 游戏管理类；
import Player from './Player.js';
class Game {
    constructor(){
        this.player = null;
    }
    login(name){
        this.player = new Player(name);
        // 初始化；
        this.player.heros.forEach(hero=>{
            //删除展示图标方法
            // hero.removeEvent("myevent",hero.showico);
             //删除全部自定义方法
             hero.removeEvent("myevent");
            hero.trigger("myevent");
        })
    }
}

// 单例模式；
let instance;
export default function(...arg){
    // 工厂模式
    if(!instance){
        instance = new Game(...arg);
    }
    return instance;
}
//提交作业时候创建一个空文件夹以暗号命名；
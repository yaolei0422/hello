// 渲染  dom结构；
// 对象  --->类（属性和方法） --->逻辑关系；
// 对象：  玩家对象   亚瑟  鲁班  ...  技能  皮肤；

import Game from "./game/Game.js";

//  Player  YaSe LuBan --> Hero(基类：父类)；  skill类-->skill（父类 、基类）；   skin --->skill（父类）；
// 游戏管理类 Game 
let game = new Game();

Function.prototype.DecoratorFn = function(fn,context,...arg){
    console.log(this);
    // 原本的逻辑
    this.call(context,...arg);
    // 装饰的方法；
    fn();
}

function Hurt(){
    console.log("造成了100点伤害");
}



// game.login("张三");
// console.log(game)
let gameEles = {
    login:{
        username:document.querySelector(".username"),
        btn:document.querySelector(".sub"),
        loginView:document.querySelector(".login")
    },
    game:{
        gameView:document.querySelector(".game"),
        chioseusername:document.querySelector(".chioseusername"),
        heroView:document.querySelector(".heroView"),
        heroShow:document.querySelector(".heroShow"),
        skillsView:document.querySelector(".skillsView"),
        heroBtn:document.querySelector(".heroBtn"),
        skinBtn:document.querySelector(".skinBtn"),
        heroContainer:document.querySelector(".heroContainer"),
        skinContainer:document.querySelector(".skinContainer"),
        skinView:document.querySelector(".skinView"),
        skinShow:document.querySelector(".skinShow img")

    }
}

gameEles.login.btn.onclick = function(){
    let username = gameEles.login.username.value;
    if(username){
        game.login(username);
        console.log(game);
        // 隐藏登录页；
        gameEles.login.loginView.style.display = "none";
        // 显示英雄选择页面；
        gameEles.game.gameView.style.display = "block";
        // 改变用户名；
        gameEles.game.chioseusername.innerHTML = "";
        gameEles.game.chioseusername.innerHTML = game.player.name;
        renderHero(game);
    }else{
        alert("请输入用户名");
    }
}

// 渲染英雄
function renderHero(game){
   let heros = game.player.heros;
   gameEles.game.heroView.innerHTML = "";
   renderSkin(heros[0]);
   heros.forEach(hero=>{
        let heroItem = document.createElement("div");
        heroItem.classList.add("heroItem");
        heroItem.innerHTML = `<img src="${hero.ico}" />
        <span>${hero.name}</span>`;
        gameEles.game.heroView.appendChild(heroItem);
        
        heroItem.onclick = function(){
            // 显示选中的英雄
            gameEles.game.heroShow.innerHTML = `<img src="${hero.ico}"/>`;
            // 渲染点击英雄的技能；
            renderSkill(hero);
            renderSkin(hero);
        }

   })
}

// 渲染技能
function renderSkill(hero){
    gameEles.game.skillsView.innerHTML = "";
    // console.log(hero);
    let skills = hero.skills;
    skills.forEach((skill,key)=>{
        let img = new Image();
        img.src = skill.ico;
        gameEles.game.skillsView.appendChild(img);
        img.onclick = function(){
            // hero.fire(key);
            hero.fire.DecoratorFn(Hurt,hero,key);

        }

    })
}

// 渲染皮肤；
function renderSkin(hero){
    //  清空容器；
    gameEles.game.skinView.innerHTML = "";
    let skins = hero.skins;
    skins.forEach(skin=>{
        let skinDiv = document.createElement("div");
        skinDiv.classList.add("skinItem");
        skinDiv.innerHTML = `<img src="${skin.ico}" />
        <span>${skin.name}</span>`;
        gameEles.game.skinView.appendChild(skinDiv);
        skinDiv.onclick = function(){
            gameEles.game.skinShow.src = skin.img;
        }
    })
}

// 作业：  扩展 鲁班类 实现技能渲染；
gameEles.game.heroBtn.onclick = function(){
    gameEles.game.heroContainer.style.display = "block";
    gameEles.game.skinContainer.style.display = "none";
}
gameEles.game.skinBtn.onclick = function(){
    gameEles.game.heroContainer.style.display = "none";
    gameEles.game.skinContainer.style.display = "block";
    
}



